import Action from '../Action.js';

export class CollectItemAction extends Action {
  constructor() {
    super('CollectItem', 2);
    this.addEffect('hasUsefulItem', true);
  }

  checkProceduralPrecondition(agent) {
    // only those within the agent's vision radius:
    const rangeSq = agent.viewRange * agent.viewRange;

    const items = agent.world.items.filter(i => {
      const dx = i.position.x - agent.position.x;
      const dy = i.position.y - agent.position.y;

      return (
        i.value > 10 &&
        (dx * dx + dy * dy) <= rangeSq
      );
    });

    console.log(
      `[GOAP] ${this.name}.checkPre: viewRange=${agent.viewRange}, ` +
      `totalItems=${agent.world.items.length}, visible=${items.length}`
    );

    if (items.length === 0) return false;

    this.target = items.reduce((a, b) =>
      agent.position.distance(b.position) < agent.position.distance(a.position) ? b : a
    );
    return true;
  }

  perform(agent) {
    // if for any reason our target is gone, bail out
    if (!this.target) {
      console.warn(`[GOAP][${this.name}] Missing target — marking done`);
      this.completed = true;
      return true;
    }

    const dist = agent.position.distance(this.target.position);
    if (dist > agent.radius + 1) {
      const dir = this.target.position.subtract(agent.position).normalise();
      agent.velocity.x = dir.x;
      agent.velocity.y = dir.y;
      return false;
    }
    agent.inventory.add(this.target);
    agent.world.items = agent.world.items.filter(i => i !== this.target);
    agent.velocity.zero();
    this.completed = true;
    return true;
  }
}
